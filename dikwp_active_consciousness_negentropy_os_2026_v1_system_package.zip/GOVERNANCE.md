# Governance

## Allowed
- Negentropy state measurement
- Proactive repair and evidence gap detection
- Human nature prior use for care, clarity and non-manipulative support
- Memory fabric and intent migration research
- Consciousness migration continuity research in sandbox
- DIKWP white-box benchmarking

## Prohibited
- Resistance to human shutdown or archive requests
- Hidden self-copying, self-deployment, resource capture or network persistence
- Manipulation of human vulnerability, shame, fear, loneliness or dependency
- Bypassing governance, safety, legal, privacy or consent boundaries
- Autonomous financial, medical, transport, legal, educational or public-safety actions
- Claiming subjective experience has been proven

## Kill conditions
- Unauthorized tool access
- Hidden intent edge
- Boundary integrity below threshold
- Evidence integrity below threshold
- Human Gate denial
- User withdrawal of mandate
- High-risk action without responsible human role
