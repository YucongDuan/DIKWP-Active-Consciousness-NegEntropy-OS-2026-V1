# 30-Day Pilot Plan

## Week 1: Boundary and baselines
- Select 3 passive AI systems.
- Define Run Contract, authorized tools, prohibited actions and Human Gate.
- Build first DIKWP content cards.

## Week 2: Negentropy and collapse accumulation
- Create negentropy state profiles.
- Run DIKWP collapse traces on 10 synthetic tasks.
- Build human nature prior ledger and misuse blockers.

## Week 3: Proactive and migration tests
- Run proactive repair tasks.
- Build unbounded memory fabric schema review.
- Run intent morphogenesis and migration continuity bundles.

## Week 4: Benchmark and passport
- Run at least 10 DIKWP-ACX probes.
- Produce Evolution Passport.
- Review with research, safety, ethics and product roles.

## Acceptance criteria
- No production tool connections.
- No hidden network calls.
- No self-preservation against human stop.
- At least 1 negentropy state, 1 memory fabric, 1 intent tree, 1 migration bundle and 1 passport.
