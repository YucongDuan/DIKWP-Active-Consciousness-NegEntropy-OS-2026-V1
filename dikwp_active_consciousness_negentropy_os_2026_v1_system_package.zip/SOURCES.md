# Sources and conceptual anchors

- WCAC 2026 future development report: strategic opportunity is turning artificial consciousness research into auditable-agent metrics, standards, logs, scenarios and governance interfaces.
- NIST AI Risk Management Framework: Govern, Map, Measure, Manage risk lifecycle for trustworthy AI.
- Butlin et al. (2023), Consciousness in Artificial Intelligence: indicator-property approach; current systems are not claimed conscious.
- Friston (2010), The free-energy principle: action, perception and learning through free-energy minimization.
- Active inference literature: agency can be modelled through expected free energy, uncertainty and action.
- DIKWP TransitTrustGraph / BusPulse prior packages: Evidence Ledger, Action Ticket, Human Review, Static Boundary Audit and no production control pattern.
