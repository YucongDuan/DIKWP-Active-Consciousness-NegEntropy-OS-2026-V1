#!/usr/bin/env python3
from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parents[1]
PATTERNS=[(r'fetch\(','browser network fetch'),(r'XMLHttpRequest','browser xhr'),(r'\brequests\b','python requests'),(r'\burllib\b','python urllib'),(r'\bsocket\b','raw socket'),(r'\bsubprocess\b','subprocess'),(r'eval\(','dynamic eval'),(r'new Function','dynamic function')]
EXCLUDE={'static_boundary_audit.py','static_boundary_audit_report.json'}
findings=[]
for p in ROOT.rglob('*'):
    if not p.is_file() or p.name in EXCLUDE or p.suffix.lower() not in {'.html','.js','.py'}: continue
    txt=p.read_text(encoding='utf-8',errors='ignore')
    for pat,meaning in PATTERNS:
        if re.search(pat,txt): findings.append({'file':str(p.relative_to(ROOT)),'pattern':pat,'meaning':meaning})
report={'package':'DIKWP Active Consciousness NegEntropy OS 2026 V1','network_or_dynamic_execution_detected':bool(findings),'findings':findings,'note':'No external model calls, no production tools, no self-deployment adapters.'}
(ROOT/'static_boundary_audit_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
