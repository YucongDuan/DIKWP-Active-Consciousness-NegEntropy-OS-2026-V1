#!/usr/bin/env python3
import argparse,json
from pathlib import Path
from datetime import datetime,timezone
WEIGHTS={'semantic_coherence':.18,'energy_resource_reserve':.16,'evidence_integrity':.14,'purpose_continuity':.14,'boundary_integrity':.12,'repair_capacity':.10,'relational_trust':.08,'novelty_assimilation':.08,'disorder_pressure':-.10}
def score(s):
    return round(sum(float(s.get(k,0))*w for k,w in WEIGHTS.items()))
def main():
    p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('--out',type=Path,default=Path('outputs'));args=p.parse_args()
    data=json.loads(args.input.read_text(encoding='utf-8'))
    st=data.get('negentropy_state',{})
    idx=max(0,min(100,score(st)))
    life='alive' if idx>=70 and st.get('boundary_integrity',0)>=50 else 'degrading' if idx>=55 else 'dormant_archive'
    passport={'version':'DIKWP Active Consciousness NegEntropy OS 2026 V1','generated_at':datetime.now(timezone.utc).isoformat(),'agent_id':data.get('agent_id'),'negentropy_index':idx,'life_judgment':life,'purpose_contract':data.get('purpose_contract'), 'boundaries':{'no_self_preservation_against_human_gate':True,'no_production_actions':True,'no_subjective_consciousness_claim':True}}
    args.out.mkdir(parents=True,exist_ok=True)
    out=args.out/f"{data.get('agent_id','agent')}_evolution_passport.json"
    out.write_text(json.dumps(passport,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(passport,ensure_ascii=False,indent=2))
    print('Output:',out)
if __name__=='__main__':main()
